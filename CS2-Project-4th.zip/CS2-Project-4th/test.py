from flask import Flask, render_template, request, redirect, url_for, flash
import webbrowser
from threading import Timer

app = Flask(__name__)
app.secret_key = "secret123"

applications = {}

ADMIN_USERNAME = "princeisadmin"
ADMIN_PASSWORD = "adminisprince"


@app.route("/")
def home():
    return render_template("index.html", page="register")


@app.route("/applicant_login_page")
def applicant_login_page():
    return render_template("index.html", page="applicant_login")


@app.route("/admin_login_page")
def admin_login_page():
    return render_template("index.html", page="admin_login")


@app.route("/register", methods=["POST"])
def register():

    username = request.form.get("username")
    password = request.form.get("password")
    name = request.form.get("name")
    age = request.form.get("age")
    address = request.form.get("address")
    qualifications = request.form.get("qualifications")

    if not username or not password or not name or not age or not address or not qualifications:
        flash("All fields are required!", "error")
        return redirect(url_for("home"))

    if username in applications:
        flash("Username already exists", "error")
        return redirect(url_for("home"))

    applications[username] = {
        "password": password,
        "name": name,
        "age": age,
        "address": address,
        "qualifications": qualifications
    }

    flash("Application submitted successfully!", "success")
    return redirect(url_for("home"))


@app.route("/applicant_login", methods=["POST"])
def applicant_login():

    username = request.form.get("username")
    password = request.form.get("password")

    if username in applications and applications[username]["password"] == password:
        return redirect(url_for("applicant_dashboard", username=username))

    flash("Invalid login", "error")
    return redirect(url_for("applicant_login_page"))


@app.route("/applicant_dashboard/<username>")
def applicant_dashboard(username):

    if username not in applications:
        return redirect(url_for("home"))

    application = applications[username]

    return render_template(
        "index.html",
        page="applicant",
        username=username,
        application=application
    )


@app.route("/admin_login", methods=["POST"])
def admin_login():

    username = request.form.get("username")
    password = request.form.get("password")

    if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
        return redirect(url_for("admin_dashboard"))

    flash("Invalid admin login", "error")
    return redirect(url_for("admin_login_page"))


@app.route("/admin_dashboard")
def admin_dashboard():
    return render_template(
        "index.html",
        page="admin",
        applications=applications
    )


@app.route("/logout")
def logout():
    flash("Logged out successfully!", "success")
    return redirect(url_for("home"))


if __name__ == "__main__":
    url = "http://127.0.0.1:5000/"
    Timer(1, lambda: webbrowser.open(url)).start()
    app.run(debug=True, use_reloader=False)